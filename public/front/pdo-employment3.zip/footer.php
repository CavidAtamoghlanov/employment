                <span style="color:white">
                    <a style="color: white!important;text-decoration:underline" href="/about-us">Haqqımızda</a> |
                    <a style="color: white!important;text-decoration:underline" href="/contact-us">Əlaqə</a>
                </span>
                <br />
                <div style="width:100%;height:5px"></div>
                <span>
                    <a class="footer-network" href="https://www.facebook.com/butagruptr" target="_blank"><i
                            style="color: blue;top:2px;" class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a class="footer-network" href="https://www.instagram.com/butagruptr/" target="_blank"><i
                            style="color: blue;top:1px;" class="fa fa-instagram" aria-hidden="true"></i></a>
                    <a class="footer-network" href="https://az.linkedin.com/company/buta-grup-azerbaijan"
                        target="_blank"><i style="color: blue;top:1px;" class="fa fa-linkedin"
                            aria-hidden="true"></i></a>
                </span>
                <br />
                <div style="width:100%;height:5px"></div>
                <span style="color:white">
                    &copy; 2021 Employment.az |
                    <a style="color: white!important;text-decoration:underline" target="_blank"
                        href="http://butagrup.az/">Buta Grup</a>
                </span>
                </footer>
                </div>
                </div>
                <div class="loader-wrapper">
                    <span class="loader">
                        <span class="loader-inner"></span>
                    </span>
                </div>
                <div class="background-wrapper"><img src="background3.jpg" alt="background"></div>
                <div class="background-wrapper1"></div>
                <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
                    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
                    crossorigin="anonymous"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
                    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
                    crossorigin="anonymous"></script>
                <script src="https://cdn.jsdelivr.net/npm/js-cookie@rc/dist/js.cookie.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.3/js/standalone/selectize.js"
                    integrity="sha512-pF+DNRwavWMukUv/LyzDyDMn8U2uvqYQdJN0Zvilr6DDo/56xPDZdDoyPDYZRSL4aOKO/FGKXTpzDyQJ8je8Qw=="
                    crossorigin="anonymous"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.3/js/selectize.min.js"
                    integrity="sha512-JiDSvppkBtWM1f9nPRajthdgTCZV3wtyngKUqVHlAs0d5q72n5zpM3QMOLmuNws2vkYmmLn4r1KfnPzgC/73Mw=="
                    crossorigin="anonymous"></script>
                <script src="https://employment.az/app.js?ver=130.0"></script>
                </body>

                </html>