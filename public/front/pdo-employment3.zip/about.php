<?php include_once "header.php" ?>
<body>
    <div class="wrapper" id="my-wrapper" style="position:absolute;top:0px;bottom:0px;left:0;right:0;overflow-x:hidden;transition:all .4s ease;">
        <div class="container d-flex" style="height: 100%;flex-direction:column;transition:all .4s ease;">
            <div id="logo" class="d-flex flex-column" style="width: 100%;margin: 0 auto;text-align:center;padding:20px 0 5px;transition: all 700ms ease;position:relative">
                <div id="logo-header" style="padding:15px 0;display: flex;flex-direction:row;align-items:center;justify-content:center;text-align:center;position:relative;transition: all 700ms ease">
                    <img onclick="window.location='/'" src="./employment-logo.png" alt="" style="cursor:pointer;object-fit:cover;height:110px;position:relative;top:-31px;right:-4px">
                    <h3  onclick="window.location='/'" id="employment" style="cursor:pointer;font-size:42px;color: white;"><a style="text-decoration: none;color:white;position:relative;" href="/">Employment<span style="position: relative;top:28px;right:59px;color:blue!important">.az</span></a></h3>
                </div>
            </div>
            <div class="row" id="main-row" style="margin:auto 0;transition: all 700ms ease">
                <div class="col-12" style="color:white;font-size:larger">
                    <p>Mərkəzi Ankarada yerləşən “Buta Grup” 2018-ci ildən etibarən İT sektorunda fəaliyyət göstərməkdədir. Sürətli dəyişən texnoloji yeniliklərə uyğunlaşaraq xidmət göstərdiyimiz şirkətlərə bu yenilikləri tətbiq etməklə biz, müştərilərimizin rəqabət qabiliyyətli və gəlirli şirkətlər olması üçün həll yolları təklif edirik. Daimi inkişafı prioritet tutan “Buta Grup” əhatə dairəsini genişləndirərək Azərbaycanda İT sektoruna yeniliklər gətirməyi hədəfləyir.</p>
                    <br/>
                    <p>Azərbaycanda bir ilk olaraq, “Buta Grup” iş axtarış prosesini sürətləndirmək və fərqli iş axtarış platformalarının nəticələrini tək bir platforma üzərindən görüntüləmək imkanı ilə iş axtarış tərzinizi dəyişməyi düşünür. Bunun üçün də hər kəsin bu xidmətdən asan istifadəsinə şərait yaratmaq məqsədilə yeni layihəsini təqdim edir...</p>
                    <br/>
                    <p><strong><u>Employment.az</u></strong> yerli mühitdə fəaliyyət göstərən müxtəlif vakansiya platformalarından işelanlarını avtomatik olaraq çəkərək iş axtarış prosesini asanlaşdırır. Bununla siz zamana qənaət edəcək, hədəflərinizə çatmaq üçün fərqli mənbələrdən yararlanacaqsınız.</p>
                    <br/>
                    <p> <strong><u>Not:</u></strong> Axtarış nəticələrində yer alan və ya bu nəticələrlə əlaqəli olan iş yerləri, işə qəbul prosesi zamanı yarana biləcək hər hansı problemə görə Employment.az və Buta Grup Azərbaycan məsuliyyət daşımır.</p>
                </div>
            </div>
            <footer style="margin-top:auto;text-align:center;padding:15px 0;font-weight:600;position:relative;color:white">
                <div onclick="window.location='/'" class="d-flex" style="cursor:pointer;margin:0 auto 10px auto;width:40px;height:40px;background-color:#fff;color:black;border-radius:50%;justify-content:center;align-items:center">
                    <i class="fa fa-arrow-left" style="font-size: 18px;" aria-hidden="true"></i>
                </div>
            <?php include_once "footer.php" ?>