<?php
header("Strict-Transport-Security:max-age=63072000");
header("Referrer-Policy: no-referrer-when-downgrade");
header('X-Content-Type-Options: nosniff');
header("X-XSS-Protection: 1");
header("X-Frame-Options: DENY");
session_start();
$_SESSION['token'] = true;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="title" content="Azərbaycanın ilk İş Axtarış Sistemi">
    <meta name="description"
        content="Azərbaycanda bir ilk olaraq, Buta Grup iş axtarış prosesini sürətləndirmək və fərqli iş axtarış platformalarının nəticələri üçün tək bir platforma">
    <meta name="keywords"
        content="Employment az,Employment.az, Job, IT, HR, search engine,İş axtarış sistemi, İş,İş axtarış saytları,Azərbaycanda iş axtarış saytları, Azərbaycanda İş,İş elanları,İş axtarış, Buta, Buta Grup">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="author" content="Employment.az">
    <title>Azərbaycanın ilk İş Axtarış Sistemi</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.3/css/selectize.bootstrap4.min.css"
        integrity="sha512-MMojOrCQrqLg4Iarid2YMYyZ7pzjPeXKRvhW9nZqLo6kPBBTuvNET9DBVWptAo/Q20Fy11EIHM5ig4WlIrJfQw=="
        crossorigin="anonymous" />
    <link rel="shortcut icon" type="image/x-icon" href="https://employment.az/employment-logo.png?ver=2.0" />
    <link rel="apple-touch-icon" href="https://employment.az/employment-logo.png?ver=2.0">
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript">
    (function(m, e, t, r, i, k, a) {
        m[i] = m[i] || function() {
            (m[i].a = m[i].a || []).push(arguments)
        };
        m[i].l = 1 * new Date();
        k = e.createElement(t), a = e.getElementsByTagName(t)[0], k.async = 1, k.src = r, a.parentNode.insertBefore(
            k, a)
    })
    (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

    ym(74326681, "init", {
        clickmap: true,
        trackLinks: true,
        accurateTrackBounce: true,
        webvisor: true
    });
    </script>
    <noscript>
        <div><img src="https://mc.yandex.ru/watch/74326681" style="position:absolute; left:-9999px;" alt="yandex" />
        </div>
    </noscript>
    <!-- /Yandex.Metrika counter -->
    <link rel="stylesheet" href="style.css?ver=102.0">
</head>